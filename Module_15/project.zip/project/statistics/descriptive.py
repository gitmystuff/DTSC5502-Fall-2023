def mean(lst: list) -> float:
  """Returns the mean of a list.

  Keyword arguments:
  lst -- list of numbers
  """
  return sum(lst) / len(lst)

def median(lst: list) -> float:
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  if len(lst) % 2 == 0: # n is even
    pass
  else:
    pass

def mode(lst):
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass