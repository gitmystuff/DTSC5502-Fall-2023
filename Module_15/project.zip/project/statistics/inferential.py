import numpy as np

def sem(s: float, n: int): # standard error of the mean
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  return s/np.sqrt(n)

def confidence_intervals():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass
  