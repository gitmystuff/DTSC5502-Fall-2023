def pdf():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass


def cdf():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass


def ppf():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass


def binom():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass


def normal(x: float, m: float, s: float) -> float:
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass
