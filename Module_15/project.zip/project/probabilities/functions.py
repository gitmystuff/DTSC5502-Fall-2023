import numpy as np
import math

def factorial(n: int) -> int:
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  # return math.factorial(n)
  return np.prod([i for i in range(1, n+1)])

def combination():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass

def exponential():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass

def compliment():
  """Purpose.

  Keyword arguments:
  arg1 -- description
  arg2 -- description
  ...
  """
  pass