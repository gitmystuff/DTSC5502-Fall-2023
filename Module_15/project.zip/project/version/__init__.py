__major_version__ = '0'
__minor_version__ = '1'
__patch_version__ = '0'

__version__ = f'DTSC5502 Version: {__major_version__}.{__minor_version__}.{__patch_version__}'